namespace PickPack;

public class Cargo
{
    public string Address { get; }

    public Cargo(string address)
    {
        Address = address;
    }
}