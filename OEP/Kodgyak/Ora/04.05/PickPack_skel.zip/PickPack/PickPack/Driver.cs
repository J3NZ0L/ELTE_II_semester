namespace PickPack;

public class Driver
{
    public string Base { get; }

    public Driver(string @base)
    {
        Base = @base;
    }

    public void Work()
    {
        
    }

    private void Back()
    {
        
    }

    private void Carry()
    {
        
    }

    private void Travel(string address)
    {
        
    }
}