﻿using System;

namespace Dispenser;

public class Dispenser
{
    // TODO
}