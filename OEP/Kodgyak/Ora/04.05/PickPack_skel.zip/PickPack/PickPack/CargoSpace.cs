namespace PickPack;

public class CargoSpace
{
    
}