namespace PickPack;

public class Vehicle
{
    private double fuelConsumption;

    public Vehicle(double fuelConsumption)
    {
        this.fuelConsumption = fuelConsumption;
    }

    public int Check(string address)
    {
        
    }

    public void Refuel(int amount)
    {
        
    }

    public void Drive(string address)
    {
        
    }

    private int Distance(string address)
    {
        
    }
}