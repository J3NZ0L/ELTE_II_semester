﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HF8
{
    internal class File : Registration
    {
        private int size;

        public override int GetSize()
        {
            return size;
        }

        public File(int size)
        {
            this.size = size;
        }
    }
}
